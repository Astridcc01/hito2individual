<?php

class Usuario{
//atributos de clase
    private $id;
    private $nombre;
    private $contrasena;
    private $repcontrasena;
    private $email;
    private $foto;
//constructor
    function __construct($id, $nombre, $contrasena, $repcontrasena, $email, $foto) {
        $this->setId($id);
        $this->setNombre($nombre);
        $this->setcontrasena($contrasena);
        $this->setRepcontrasena($repcontrasena);
        $this->setEmail($email);
        $this->setFoto($foto);

    }
    
    public function getId()
    {
        return $this->id;
    }
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }
    public function getNombre()
    {
        return $this->nombre;
    }
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;

        return $this;
    }
    public function getContrasena()
    {
        return $this->contrasena;
    }
    public function setContrasena($contrasena)
    {
        $this->contrasena = $contrasena;

        return $this;
    }

    public function getRepcontrasena()
    {
        return $this->repcontrasena;
    }
    public function setRepcontrasena($repcontrasena)
    {
        $this->repcontrasena = $repcontrasena;

        return $this;
    }

    public function getEmail()
    {
        return $this->email;
    }
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    public function getFoto()
    {
        return $this->foto;
    }
    public function setFoto($foto)
    {
        $this->foto = $foto;

        return $this;
    }

    public static function show()
    {
        $conexion = Db::getConnect();

        $select = $conexion->query('SELECT * FROM usuarios');
        foreach($select->fetchAll() as $usuario){
			$listaUsuarios[]=new Usuario($usuario['id'],$usuario['nombre'],$usuario['contrasena'],$usuario['repcontrasena'],$usuario['email'],$usuario['foto']);
		}
		require_once('Views/Usuario/show.php');
    }
    public static function delete($id)
    {
        $conexion = Db::getConnect();
        $select = $conexion->prepare('DELETE FROM usuarios
        WHERE id = :id');
        $select->bind_param(':id',$id);
        $select->execute();
        // echo($id);
		require_once('Views/Usuario/update.php');
    }
   
}