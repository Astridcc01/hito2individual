<?php

class UsuarioController
{
    //atributos de clase
    
    //constructor
    function __construct(){

    }
    //getters and setters

    //resto de metodos - implementa de APIService(CRUD)
    function index()
    {
        require_once("Views/Usuario/bienvenido.php");
    }
    function register()
    {
        require_once("Views/Usuario/register.php");
    }
    function save()
    {
        // if (isset($_POST["id"])) {
        //     $usuario = new Usuario($_POST["id"], $_POST["nombre"], $_POST["contrasena"], $_POST["repcontrasena"], $_POST["email"], $_POST["foto"]);
        // }else{
        //     $usuario = new Usuario(NULL, $_POST["nombre"], $_POST["contrasena"], $_POST["repcontrasena"], $_POST["email"], $_POST["foto"]);
        // }
        // Usuario::save($usuario);

        $nombre=$_POST["nombre"];
        $contrasena=$_POST["contrasena"];
        $repcontrasena=$_POST["repcontrasena"];
        $email=$_POST["email"];
        $foto=$_POST["foto"];

        $conexion = Db::getConnect();
        
        $insertar = $conexion->query("INSERT INTO usuarios (nombre, contrasena, repcontrasena, email, foto) VALUES ('$nombre','$contrasena','$repcontrasena','$email','$foto')");
        //var_dump($insertar);
        // require_once('Views/Usuario/update.php');
        Usuario::show();

    }
    function show(){
        Usuario::show();
    }
    function delete(){
        // Usuario::delete($_POST["id"]);
        require_once('Views/Usuario/delete.php');
        
    }
    /* function showI(){
        Usuario::showI($_POST["id"]);
    } */

    function eliminar(){
        $id=$_POST["id"];

        $conexion = Db::getConnect();
        
        $insertar = $conexion->query("DELETE FROM usuarios WHERE id=$id");
        //var_dump($insertar);
        require_once('Views/Usuario/bienvenido.php');
        Usuario::show();
    }

    function error(){
        require_once('Views/Usuario/error.php');
    }

    function update(){
        require_once('Views/Usuario/update.php');
    }
    function actualizar(){
        $nombre=$_POST["nombre"];
        $contrasena=$_POST["contrasena"];
        $repcontrasena=$_POST["repcontrasena"];
        $email=$_POST["email"];
        $foto=$_POST["foto"];

        $conexion = Db::getConnect();

        $actualizar = $conexion->query("UPDATE usuarios SET contrasena='$contrasena', repcontrasena='$repcontrasena', email='$email', foto='$foto' WHERE usuarios.nombre='$nombre'");
        
        Usuario::show();
    }
}// cierra clase
