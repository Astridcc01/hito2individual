<form action="?controller=usuario&&action=save" method="POST">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Nombre</label>
    <input type="text" class="form-control" name="nombre" aria-describedby="emailHelp">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Contraseña</label>
    <input type="password" class="form-control" name="contrasena">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Repetir contraseña</label>
    <input type="password" class="form-control" name="repcontrasena">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Email</label>
    <input type="email" class="form-control" name="email">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Foto</label>
    <input type="url" class="form-control" name="foto">
  </div>
  <button type="submit" class="btn btn-primary">Añadir usuario</button>
</form>