<h1>ELIMINAR USUARIO</h1>

<form action="?controller=usuario&action=eliminar" method="post">
    <div class="form-outline flex-fill mb-0">
        <label class="form-label" for="nombre">ID de usuario que desea eliminar:</label>
        <input type="text" id="id" class="form-control" name="id"/>
    </div>
    <br>
        <input type="submit" value="Eliminar perfil" class="btn btn-primary btn-lg">
</form>