<h2>Todos los usuarios</h2>
<table class="table table-strip">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Contraseña</th>
            <th>Repetir contraseña</th>
            <th>Email</th>
            <th>Foto</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($listaUsuarios as $usuario) {?>
        <tr>
            <td><?php echo $usuario->getId(); ?></td>
            <td><?php echo $usuario->getNombre(); ?></td>
            <td><?php echo $usuario->getContrasena(); ?></td>
            <td><?php echo $usuario->getRepcontrasena(); ?></td>
            <td><?php echo $usuario->getEmail(); ?></td>
            <td><img src="<?php echo $usuario->getFoto(); ?>" width="200px"> </td>
            <td><form action="?controller=usuario&&action=delete" method="post"><button type="submit" class="btn btn-danger">Eliminar</button> <input type="hidden" name="id" value="<?php echo $usuario->getId(); ?>"></form>   </td>
            <td><form action="?controller=usuario&&action=update" method="post"><button type="submit" class="btn btn-success">Modificar</button> <input type="hidden" name="id" value="<?php echo $usuario->getId(); ?>"></form>   </td>
        </tr>
        <?php } ?>    
    </tbody>
    
    
    
</table>